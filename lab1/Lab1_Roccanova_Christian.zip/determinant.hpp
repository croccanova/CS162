/******************************************************
Program Name: Lab1
Author: Christian Roccanova
Date: 4/7/2017
Description: Header for determinant.cpp
******************************************************/

#ifndef determinant_hpp
#define determinant_hpp

// prototype for determinant function
void determinant(int**, int);

#endif 