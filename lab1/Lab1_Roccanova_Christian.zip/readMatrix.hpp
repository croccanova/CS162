/******************************************************
Program Name: Lab1
Author: Christian Roccanova
Date: 4/7/2017
Description: Header for readMatrix.cpp
******************************************************/

#ifndef readMatrix_hpp
#define readMatrix_hpp

// prototype for readMatrix function
void readMatrix(int**, int);

#endif